# dkim/

Bu dizin domain adlarına özel DKIM anahtarlarını içerir.

Dosya yapısı örnek olmak üzre şu şekildedir:

```bash
dkim/
├── domainname.com/mail.txt
├── domainname1.com/mail.txt
└── domainname2.com/mail.txt
```
