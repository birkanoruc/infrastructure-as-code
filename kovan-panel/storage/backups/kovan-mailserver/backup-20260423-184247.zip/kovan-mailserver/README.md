# docker-mailserver/

Tek bir docker-mailserver container kullanarak, birden fazla domain için e-posta adreslerini yönetebileceğimiz esnek ve merkezi bir yapı kurmayı amaçlar. Bu yapı sayesinde minimum kaynak tüketimi ile mailserver yönetim pratikliği hedeflenir.

```bash
docker-mailserver/
├── docker-compose.yml
├── mailserver.env
└── config/
```

## docker-compose.yml

Bu dosya birden fazla domain destekleyebilen docker-mailserver container’ını başlatır.

### docker-mailserver

**docker-mailserver** servis yapısını oluşturmak için aşağıdaki kod bloğunu özelleştirerek **docker-compose.yml** dosyasına ekleyelim:

```bash
version: '3.8'

services:
  mailserver:
    image: mailserver/docker-mailserver:latest    # Kullanılacak Docker Mailserver imajının adı ve etiketi
    container_name: mailserver                    # Oluşturulacak Docker konteynerinin adı
    hostname: mail                                # Konteynerin içindeki hostname (örn: mail)
    domainname: domainname.com                    # Posta sunucusunun hizmet vereceği ana domain adı (Reverse DNS için önemli, aynı olmalı)
    env_file: mailserver.env                      # Ortam değişkenlerinin tanımlandığı dosya (örneğin parolalar)
    ports:
      - "25:25"                                   # SMTP (e-posta gönderme) için dışarıdan erişilecek port:iç port
      - "465:465"                                 # SMTPS (SSL/TLS ile güvenli e-posta gönderme) için dışarıdan erişilecek port:iç port
      - "587:587"                                 # Submission (istemcilerden e-posta gönderme) için dışarıdan erişilecek port:iç port
      - "993:993"                                 # IMAPS (SSL/TLS ile güvenli e-posta alma) için dışarıdan erişilecek port:iç port
    volumes:
      - maildata:/var/mail                        # E-posta verilerinin saklanacağı Docker volümü:konteyner içi dizin
      - mailstate:/var/mail-state                 # Posta sunucusunun durum bilgilerinin saklanacağı Docker volümü:konteyner içi dizin
      - maillogs:/var/log/mail                    # Posta sunucusu loglarının saklanacağı Docker volümü:konteyner içi dizin
      - ./config/:/tmp/docker-mailserver/         # Yerel dizindeki yapılandırma dosyalarının konteyner içine kopyalanacağı dizin
    restart: always                               # Konteyner herhangi bir nedenle durursa otomatik olarak yeniden başlatılır
    cap_add:
      - NET_ADMIN                                 # Ağ yapılandırması ile ilgili yetenekler ekler (gerekli olabilir)
      - SYS_PTRACE                                # Sistem çağrılarını izleme yeteneği ekler (bazı araçlar için gerekebilir)

volumes:
  maildata:                                       # E-posta verilerinin saklanacağı Docker volümü
  mailstate:                                      # Posta sunucusunun durum bilgilerinin saklanacağı Docker volümü
  maillogs:                                       # Posta sunucusu loglarının saklanacağı Docker volümü
```

**Not:** Bu yapı mail.domainname.com üzerinden yapılandırılır. Ancak tüm domainler için e-posta oluşturabiliriz. Sadece PTR (reverse DNS) kaydı bu alan adına işaret etmeli.

### snappymail

**snappymail** servis yapısını oluşturmak için **docker-compose.yml** dosyasına aşağıdaki kod bloğunu isteğe bağlı (özelleştirerek) ekleyelim:

```bash
snappymail:
  image: thelounge/snappymail                     # Kullanılacak SnappyMail imajının adı ve etiketi (thelounge organizasyonundan)
  container_name: snappymail                      # Oluşturulacak Docker konteynerinin adı
  restart: always                                 # Konteyner herhangi bir nedenle durursa otomatik olarak yeniden başlatılır
  ports:
    - "8080:80"                                   # Host makinenin 8080 portunu konteynerin 80 portuna yönlendirir (HTTP erişimi için)
  volumes:
    - ./snappymail-data:/data                     # Yerel dizindeki snappymail-data klasörünü konteynerin /data dizinine bağlar (veri kalıcılığı için)
```

**Not:** 8080 portu üzerinden, yani **http://your-server-ip:8080** webmail arayüze erişeceğiz. Dilerseniz nginx ters proxy ile subdomain üzerinden, yani **http://mail.domain.com** olarak bağlayabilirsiniz.

**SnappyMail Ayarları**

1. İlk açtığında kurulum sihirbazı gelir.

2. Sunucu ayarlarını gir:

IMAP Host: mail veya mail.domainname.com

SMTP Host: mail veya mail.domainname.com

Bağlantı portlarını doğru gir (143, 993, 465 vs.)

TLS destekli girişleri aktifleştir.

3. Kullanıcı girişi: docker-mailserver'da oluşturduğun kullanıcılar ile doğrudan giriş yapılabilir. Örn:

username@domainname.com

Parola: senin oluşturduğun parola

3. (Opsiyonel) Ters Proxy ile mail.domainname.com Alt Alan Adı Kullanmak

Eğer Nginx ile yönlendiriyorsan bir subdomain tanımlayıp bu servise yönlendirebiliriz.

```bash
server {
    listen 80;                                       # Bu sunucu bloğunun HTTP (80) portunu dinleyeceğini belirtir.
    server_name mail.domainname.com;                 # Bu sunucu bloğunun hangi alan adına (mail.domainname.com) gelen istekleri işleyeceğini belirtir.

    location / {                                     # Kök dizine (/) yapılan tüm istekler için geçerli olan bir konum bloğu tanımlar.
        proxy_pass http://localhost:8080;            # İstekleri localhost üzerindeki 8080 portunda çalışan uygulamaya (örneğin SnappyMail) yönlendirir.
        proxy_set_header Host $host;                 # Orijinal isteğin Host başlığını hedef uygulamaya iletir. Bu, uygulamanın doğru sanal ana bilgisayarı (virtual host) bilmesini sağlar.
        proxy_set_header X-Real-IP $remote_addr;     # İstemcinin gerçek IP adresini X-Real-IP başlığı altında hedef uygulamaya iletir. Bu, loglama veya erişim kontrolü gibi amaçlar için faydalıdır.
    }
}
```

## mailserver.env

Bu dosya docker-mailserver container'ının nasıl davranacağını belirler.

Aşağıdaki kod bloğunu **mailserver.env** dosyasına özelleştirerek ekleyelim:

```bash
# Zorunlu ayarlar
ENABLE_FAIL2BAN=1                                       # Fail2ban'ı etkinleştirir. Bu, başarısız giriş denemelerini izleyerek sunucuyu kaba kuvvet saldırılarına karşı korur.
ENABLE_CLAMAV=0                                         # Antivirüs. Düşük RAM'li sistemlerde kapalı tutmak daha iyi. ClamAV'ı devre dışı bırakır. E-postaları virüslere karşı taramaz. Düşük kaynaklı sistemlerde performansı artırabilir.
ENABLE_POSTGREY=0                                       # Postgrey'i devre dışı bırakır. Postgrey, ilk kez e-posta gönderen sunucuları geçici olarak reddederek spam'ı azaltmaya çalışan bir mekanizmadır.
ONE_DIR=1                                               # Tüm posta kutularının tek bir dizinde saklanmasını sağlar. Bu, yönetim ve yedekleme işlemlerini kolaylaştırabilir.
TZ=Europe/Istanbul                                      # Sunucunun saat dilimini Avrupa/İstanbul olarak ayarlar. Bu, zaman damgalarının doğru olmasını sağlar.

# Kullanıcı / domain ayarları
POSTMASTER_ADDRESS=postmaster@domainname.com            # Postmaster e-posta adresini tanımlar. Sistem tarafından üretilen bildirimler ve hatalar bu adrese gönderilir.
PERMIT_DOCKER=host                                      # Docker'ın host ağını kullanmasına izin verir. Bu, konteynerin doğrudan host makinenin ağ arayüzlerini kullanmasını sağlar.
SUPERVISOR_LOGLEVEL=warn                                # Supervisor servis yöneticisinin log seviyesini "warn" olarak ayarlar. Bu seviyede sadece uyarılar ve daha ciddi olaylar loglanır.

# Güvenlik / TLS
SSL_TYPE=manual                                         # Let's Encrypt kurulacaksa 'manual'. SSL/TLS sertifikalarının manuel olarak sağlanacağını belirtir. Let's Encrypt gibi araçlarla sertifika alınıp bu yollara yerleştirilebilir.
SSL_CERT_PATH=/tmp/docker-mailserver/ssl/fullchain.pem  # SSL sertifika dosyasının yolunu belirtir. Tam sertifika zinciri (sertifika + ara sertifikalar) bu dosyada olmalıdır.
SSL_KEY_PATH=/tmp/docker-mailserver/ssl/privkey.pem     # SSL özel anahtar dosyasının yolunu belirtir. Bu dosya gizli tutulmalıdır.

# Spamlardan korunma
ENABLE_SPAMASSASSIN=1                                   # SpamAssassin'i etkinleştirir. SpamAssassin, e-postaları analiz ederek spam olup olmadıklarını belirlemeye yardımcı olan bir araçtır.
SPAMASSASSIN_SPAM_TO_INBOX=1                            # Spam olarak işaretlenen e-postaların doğrudan gelen kutusuna teslim edilmesini sağlar. Genellikle bu ayar yerine MOVE_SPAM_TO_JUNK tercih edilir.
MOVE_SPAM_TO_JUNK=1                                     # Spam olarak işaretlenen e-postaların "Junk" (Çöp Kutusu) klasörüne taşınmasını sağlar.

# DKIM desteği
ENABLE_DKIM=1                                           # DKIM (DomainKeys Identified Mail) imzalama özelliğini etkinleştirir. DKIM, gönderilen e-postaların gerçekten belirtilen alan adından geldiğini doğrulamaya yardımcı olur.
OPENDKIM_KEY_LENGTH=2048                                # Oluşturulacak DKIM anahtarının uzunluğunu 2048 bit olarak ayarlar. Daha uzun anahtarlar daha güvenlidir.
```

**Not:** Eğer SSL kullanmak istemiyorsan SSL_TYPE=letsencrypt veya SSL_TYPE=none olarak değiştirebilirsin.
Ama biz ileride Let's Encrypt üzerinden bir nginx proxy ile SSL kuracağımız için manual en uygun olanı.

## config/

Bu dizin docker-mailserver yapılandırmalarını içerir.

# Reverse DNS (PTR) Kaydı

Bu sadece barındırma sağlayıcınız tarafından ayarlanabilir. Host IP adresinin **mail.domainname.com** adresinde çözümlenmesi gerekir. Genelde sadece bir domain için yapılabilir.

```bash
MX -> mail.domainname.com
PTR(Reverse DNS) -> HOST_IP <-> mail.domainname.com
```

Bu yüzden genellikle ana domain olarak bir tanesini reverse DNS'e tanıtırsın (örneğin **domainname.com**), diğer domainlerde sorun olmaz ama bazen spam filtreleri bu domaini daha güvenilir görür.

**Not:** DNS ayarlarını yaptıktan sonra propagation için 15-60 dakika arasında beklemen gerekebilir.

# DNS Yapılandırması

## 1. MX (Mail Exchange) Kaydı

| Tip | Hostname       | Değer               | Öncelik |
| --- | -------------- | ------------------- | ------- |
| MX  | domainname.com | mail.domainname.com | 10      |

Bu, e-posta trafiğini **mail.domainname.com** adresine yönlendirecektir.
Aynı yapı **domainname2.com**, **domainname3.com** gibi diğer domainler için de yapılmalı.

## 2. A (Address) Kaydı

**mail.domainname.com** adresinin sunucu IP adresine işaret etmesi gerekir.

| Tip | Hostname            | Değer   |
| --- | ------------------- | ------- |
| A   | mail.domainname.com | HOST_IP |

Bu A kaydı MX’in işaret ettiği hostname ile eşleşmeli.

## 3. SPF (Sender Policy Framework) Kaydı

SPF kaydı, hangi sunucuların bu domain adına mail gönderebileceğini belirler.

| Tip | Hostname       | Değer                        |
| --- | -------------- | ---------------------------- |
| TXT | domainname.com | "v=spf1 mx ip4:HOST_IP -all" |

**ip4:** kısmına kendi sunucunuzun IP adresini yazın.
Birden fazla IP varsa aralarına boşluk koyabilirsiniz.

## 4. DKIM (Domain Keys Identified Mail) Kaydı

DKIM anahtarı her domain için ayrı oluşturulmuştur.

Örneğin domainname.com için **config/dkim/domainname.com/mail.txt** dosyasını açtığınızda şöyle bir şey göreceksiniz:

```bash
mail._domainkey IN TXT ( "v=DKIM1; k=rsa; p=MIIBIjANBg..." ) ; ----- DKIM key mail for domainname.com
```

Bunu domain paneline aynen ekleyin:

| Tip | Hostname         | Değer            |
| --- | ---------------- | ---------------- |
| TXT | mail.\_domainkey | mail.txt içeriği |

## 5. DMARC (Domain-based Message Authentication Reporting Conformance) Kaydı (Opsiyonel ama önerilir)

DMARC, SPF ve DKIM başarısız olduğunda nasıl davranılacağını belirler.

| Tip | Hostname               | Değer                                               |
| --- | ---------------------- | --------------------------------------------------- |
| TXT | \_dmarc.domainname.com | "v=DMARC1; p=none; rua=mailto:dmarc@domainname.com" |

**p=none** yerine **p=quarantine** veya **p=reject** da kullanılabilir. Başlangıç için none önerilir.

# Mail Server Başlatma

## 1. docker-mailserver Container’ını Başlat

**docker-compose.yml** dosyasının bulunduğu dizine gidelim.

```bash
cd ~/docker-mailserver
```

Docker konteynerini başlatalım.

```bash
docker compose up -d
```

**Not:** Bu komutla container arka planda başlatılır. İlk çalıştırmada biraz zaman alabilir.

## 2. Mail Kullanıcısı Oluştur

```bash
docker exec -it mailserver setup email add username@domainname.com mypassword
docker exec -it mailserver setup email add username@domainname1.com anotherpassword
```

Her domain için ayrı kullanıcılar oluşturabilirsin.

## 3. Test: Mail Gönderimi (Terminalden)

Container içine girip **swaks** komutunu kullanarak SMTP üzerinden test edebilirsin.
Opsiyonel olarak swaks kurmak istemezsen, onun yerine PHP veya Laravel ile test edebilirsiniz.

### Swaks Kurulumu (Opsiyonel)

```bash
apt update && apt install swaks -y
```

### Swaks ile Test Mail Gönderimi (Opsiyonel)

```bash
swaks --to yourmailaddress@example.com --from username@domainname.com --server localhost --auth LOGIN --auth-user username@domainname.com --auth-password yourwebMailPassword --data "Subject: Merhaba\n\nNasılsın?"
```

Burada yer alan **yourmailaddress@example.com** e-posta'yı göndermek istediğiniz (test etmek için kullandığınız kendi gmail hesabınız olabilir) **username@domainname.com** e-posta'yı gönderecek olan webmail adresi ve **yourWebmailPassword** yerine de webmail şifresini yazmanız gerekmektedir.

## 4. Log Kayıtlarını Kontrol Et (Opsiyonel)

```bash
docker logs -f mailserver
```

Gönderim sonrası buradan hataları/logları görebilirsin.

## 5. Güvenlik Duvarı Kontrolü (UFW veya iptables)

1. Ufw Kontrolü

```bash
ufw status
```

Eğer "command not found" derse **ufw** yüklü değildir.

Ufw kurmak için şu komutları kullanabilirsin.

```bash
sudo apt update && apt install ufw -y
```

2. Ufw Aktif Etme

```bash
sudo ufw enable
```

3. Port İzinleri

```bash
sudo ufw allow 25,465,587,143,993/tcp
sudo ufw reload
```

Bu komut ile mail sunucusu dış dünyadan (örneğin Gmail'den veya Thunderbird'den) erişilebilir olmalı.
