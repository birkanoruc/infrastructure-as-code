# config/

Bu dizin docker-mailserver yapılandırmalarını içerir.

Dosya yapısı şu şekildedir:

```bash
config/
├── postfix-accounts.cf
├── postfix-virtual.cf
└── dkim/
```

## postfix-accounts.cf

Bu dosya e-posta adreslerini ve parolalarını içerir. Parolalar hashlenmiş olmalıdır.

Aşağıdaki kod 3 farklı domain için birer örnek içerir. E-posta adreslerini ve domain isimlerini özelleştirerek **postfix-accounts.cf** dosyasına ekleyiniz:

```bash
username@domainname.com|$(DOVECOT_HASHED_PASSWORD)
username@domainname2.com|$(DOVECOT_HASHED_PASSWORD)
username@domainname3.com|$(DOVECOT_HASHED_PASSWORD)
```

Parola hashleme komutu:

```bash
docker run --rm docker.io/mailserver/docker-mailserver:latest \
bash -c "doveadm pw -s SHA512-CRYPT"
```

Ardından kullanmak istediğiniz parolayı girmeniz beklenecek. Daha sonra sana şöyle bir çıktı verecek:

```bash
{SHA512-CRYPT}$6$randomhash....
```

Bunu **postfix-accounts.cf** adlı dosyaya yapıştıracağız.

```bash
username@domainname.com|{SHA512-CRYPT}$6$4q2kAbCdEfG....
```

## postfix-virtaul.cf

Bu dosya alias tanımlamalarını içerir.

**Not:** Bu dosya opsiyoneldir.

```bash
username@domainname.com username1@domainname.com
```

**username@domainname.com** adresine gelen e-postalar **username1@domainname.com** adresine yönlendirilir.

## dkim/

Bu dizin DKIM anahtarlarını içerir.

Her domain için bir kereye mahsus DKIM anahtarı oluşturmalıyız:

```bash
docker run --rm -v "$(pwd)/config":/tmp/docker-mailserver mailserver/docker-mailserver:latest \
  setup config dkim
```

Bu komut sonucunda **config/dkim/domainname.com/mail.txt** gibi dosyalar oluşur.

**Not:** Bu dosyadaki DNS kaydını domain paneline eklememiz gerekecek.
